# Pyarmor 8.5.2 (pro), 005556, 2024-04-26T22:17:31.856391
from .pyarmor_runtime import __pyarmor__
